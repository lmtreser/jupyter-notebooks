metadata(
    description='Lightweight MQTT client for MicroPython ("robust" version).', version="1.0.2"
)

# Originally written by Paul Sokolovsky.

package("umqtt")
