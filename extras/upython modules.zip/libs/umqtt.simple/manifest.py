metadata(description="Lightweight MQTT client for MicroPython.", version="1.5.0")

# Originally written by Paul Sokolovsky.

package("umqtt")
