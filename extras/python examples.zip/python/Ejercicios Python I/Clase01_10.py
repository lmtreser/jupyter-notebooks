# Acabas de abrir una caja de ahorros que te 
# ofrece el 40% de interés al año. Estos dividendos
# se cobran a fin de año, y se añaden al balance
# final de tu caja de ahorros. Escribir un programa
# que comience leyendo la cantidad de dinero 
# depositada en la caja de ahorros, introducida por
# el usuario. Después el programa debe calcular y
# mostrar por pantalla la cantidad de ahorros tras
# el primer, segundo y tercer años. Redondear cada
# cantidad a dos decimales.


dinero_depositado = float(input("Ingrese la cantidad de dinero depositada en la caja de ahorros: "))

dividendos1 = dinero_depositado + dinero_depositado * 0.4
dividendos2 = dividendos1 + dividendos1 * 0.4
dividendos3 =  dividendos2 + dividendos2 * 0.4

print("El dinero tras el primer año es: ", round(dividendos1, 2))
print("El dinero tras el segundo año es: ", round(dividendos2, 2))
print("El dinero tras el tercer año es: ", round(dividendos3, 2))

