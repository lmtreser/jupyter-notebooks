# Una panadería vende el kilogramo de pan a 149 pesos. El
# pan que no es el día tiene un descuento del 60%. 
# Escribir un programa que pida la cantidad de kilogramos 
# de pan vendidos que no son del día, y muestre el precio 
# habitual del pan, el descuento que se le hace por no ser 
# fresco y dinero total obtenido en la venta.

kg_pan_vendido = float(input("Ingrese la cantidad de kilogramos de pan vendidos que no son del día: "))
importe_habitual = 149 * kg_pan_vendido
descuento = importe_habitual * 0.6
total = importe_habitual - descuento

print("El importe habitual del pan es: ", importe_habitual)
print("El descuento que se le hace por no ser fresco es: ", descuento)
print("El total obtenido en la venta es: ", total)

