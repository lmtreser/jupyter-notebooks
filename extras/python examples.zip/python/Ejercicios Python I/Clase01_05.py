# Escribir un programa que pregunte al usuario por el
# número de horas mensuales trabajadas y el importe 
# que percibe por hora. Mostrar por pantalla la paga 
# que le corresponde.

numero_de_horas = int(input("¿Cuántas horas trabajaste? : "))
importe_por_hora = float(input("¿Cuánto te paga por hora? : "))

paga = numero_de_horas * importe_por_hora

print("Tu paga es de: " + str(paga))


