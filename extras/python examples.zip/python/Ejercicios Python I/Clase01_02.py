# Escribir un programa que almacene la cadena ¡Hola Mundo! en una variable 
# y luego muestre por pantalla el contenido de la variable.

cadena = "Hola Mundo"
print(cadena)