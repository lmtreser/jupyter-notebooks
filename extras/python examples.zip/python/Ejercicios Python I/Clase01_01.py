# Escribir un programa que muestre por pantalla la cadena ¡Hola Mundo!.

print("Hola Mundo")