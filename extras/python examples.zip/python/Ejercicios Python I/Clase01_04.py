# Escribir un programa que muestre por pantalla el 
# resultado de la siguiente operación aritmética: 
#
# ( (17 - 5) / (2 * 3)) ** 3

resultado = ( (17 - 5) / (2 * 3)) ** 3
print(resultado)
