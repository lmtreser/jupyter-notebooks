# Un comerciante vende dos productos, A y B, por
# internet. La empresa de correos le cobra por el
# peso de cada paquete, así que necesita calcular
# el peso de todos los productos A y B que se 
# incluirán en cada envío. Cada unidad de A pesa
# 150 g y unidad de B pesa 400 g. Escribir un 
# programa que lea el número de productos de cada
# clase a enviar, y calcule el peso total del paquete.

cantidadA = int(input("Ingrese la cantidad de productos de la clase A: "))
cantidadB = int(input("Ingrese la cantidad de productos de la clase B: "))

peso = (cantidadA * 150) + (cantidadB * 400)

print("El peso total del paquete es: " + str(peso))
