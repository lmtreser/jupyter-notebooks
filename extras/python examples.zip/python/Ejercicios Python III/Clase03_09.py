# Escribir un programa que almacene en una lista los
# siguientes precios, 50, 75, 46, 22, 80, 65, 8, y
# muestre por pantalla el menor, el mayor y el promedio
# de los precios.

lista = [50, 75, 46, 22, 80, 65, 8]

menor = min(lista)
mayor = max(lista)
promedio = sum(lista) / len(lista)

print("El menor precio es: ", menor)
print("El mayor precio es: ", mayor)
print("El promedio de los precios es: ", promedio)

