# Escribir un programa que pida al usuario una palabra
# y muestre por pantalla si es un palíndromo.

palabra = input("Ingrese una palabra: ")

palabra_invertida = ""
for letra in palabra:
    palabra_invertida = letra + palabra_invertida

if palabra == palabra_invertida:
    print("La palabra es un palíndromo")
