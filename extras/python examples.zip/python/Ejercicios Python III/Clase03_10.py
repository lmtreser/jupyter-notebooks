# Escribir un programa que muestre un menú de opciones
# y permita al usuario seleccionar una de ellas. Luego, 
# escribir en pantalla “La opción elegida es <opción>”.
# Si el usuario selecciona la opción “Salir” el programa
# finaliza.

while True:
    print()
    print("1. Ingresar nuevo alumno")
    print("2. Borrar datos")
    print("3. Imprimr lista")        
    print("4. Salir")
    print()
    opcion = input("Ingrese una opcion: ")
    print()
    if opcion == "1":
        print("Ingresar nuevo alumno")
    elif opcion == "2":
        print("Borrar datos")
    elif opcion == "3":
        print("Imprimr lista")
    elif opcion == "4":
        print("Salir")
        break
    else:
        print("Opcion no valida")







