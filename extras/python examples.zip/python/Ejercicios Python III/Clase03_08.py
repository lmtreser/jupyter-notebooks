# Escribir un programa que pida al usuario una palabra
# y muestre por pantalla el número de veces que contiene
# cada vocal.

palabra = input("Ingrese una palabra: ")

for letra in "aeiou":
    print(letra, palabra.count(letra))

