# Escribir un programa que pregunte al usuario
# los 6 números ganadores de un sorteo, los 
# almacene en una lista y los muestre por pantalla
# ordenados de menor a mayor.

numeros = []

for i in range(6):
    numero = int(input("Ingrese un número: "))
    numeros.append(numero)

numeros.sort()

for numero in numeros:
    print(numero)