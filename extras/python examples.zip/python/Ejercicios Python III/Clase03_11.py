# Almacenar en una estructura de datos la información
# del nombre y notas de un grupo de 3 alumnos. Luego,
# imprimir el nombre de cada uno con su promedio y una
# leyenda que indique si está aprobado o no.


datos = [
    {"nombre": "Juan",  "n1": 10, "n2": 10, "n3": 10},
    {"nombre": "Pedro", "n1": 5,  "n2": 5,  "n3": 5},
    {"nombre": "Maria", "n1": 8,  "n2": 8,  "n3": 8}
]    

for alumno in datos:
    promedio = (alumno["n1"] + alumno["n2"] + alumno["n3"]) / 3
    if promedio >= 7:
        print(alumno["nombre"], "aprobado")
    else:
        print(alumno["nombre"], "desaprobado")




