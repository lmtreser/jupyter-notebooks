# Escribir un programa que almacene las asignaturas
# de un curso (por ejemplo Matemáticas, Física, 
# Química, Historia y Lengua) en una lista y muestre 
# por pantalla el mensaje Yo estudio <asignatura>, 
# donde <asignatura> es cada una de las asignaturas 
# de la lista.

asignaturas = ["Matemáticas", "Física", "Química", "Historia", "Lengua"]

for asignatura in asignaturas:
    print("Yo estudio", asignatura)