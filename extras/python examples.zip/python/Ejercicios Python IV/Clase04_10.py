# Escribir una función que reciba una lista de 
# números enteros, y regrese otra lista que 
# contenga unicamente los números que sean pares.


def pares(numeros):
    pares = []
    for numero in numeros:
        if numero % 2 == 0:
            pares.append(numero)
    return pares


lista = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

print(pares(lista))

