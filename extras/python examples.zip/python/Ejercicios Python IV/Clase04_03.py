# Escribir una función que reciba un número entero
# positivo y devuelva su factorial.

def factorial(numero): 
    if numero < 0: 
        print("No existe el factorial de un número negativo")

    elif numero == 0: 
        return 1
        
    else: 
        fact = 1
        while(numero > 1): 
            fact *= numero 
            numero -= 1
        return fact 



numero = 10; 
print("El factorial de", numero, "es", factorial(numero))



# Otra opcion, usando recursividad:
#
# def factorial(numero):
#   if numero < 0: 
#       print("No existe el factorial de un número negativo")
#   if numero == 0:
#       return 1
#   else:
#       return numero * factorial(numero - 1)

