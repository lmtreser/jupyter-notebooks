# Escribir una función que reciba una muestra de 
# números en una lista y devuelva otra lista con 
# sus cuadrados.

def cuadrados (lista):
    lista_cuadrados = []
    for i in lista:
        lista_cuadrados.append(i ** 2)
    return lista_cuadrados


lista = [1, 5, 6, 10, -4]

print(lista)
print(cuadrados(lista))