# Escribir una función que reciba una lista con
# los nombres de los alumnos de un curso, sus 
# promedios y el valor mínimo necesario para aprobar,
# y muestre solamente los que no deben recursar.

def aprobados(alumnos):
    for alumno in alumnos:
        if alumno[1] >= 7:
            print(alumno[0], ":", alumno[1])



# Defino un arreglo para almacenar los datos y 
# promedio de los alumnos
datos = [
    ["Perez, Juan", 10 ], 
    ["Gonzalez, Maria", 9 ], 
    ["Lopez, Maria", 8 ], 
    ["Gonzalez, Juan", 7 ], 
    ["Perez, Maria", 6 ]
    ]

aprobados( datos)
