# Escribir una función que muestre por pantalla el
# saludo ¡Hola amiga! cada vez que se la invoque.

def saludo():
    print("¡Hola amiga!")


saludo()