# Escribir una función que reciba una lista de números
# enteros, y regrese otra lista que contenga el promedio
# de los que sean menores que 10.


def promedio(numeros):
    promedio = 0
    cantidad = 0
    for numero in numeros:
        if numero < 10:
            promedio += numero
            cantidad += 1
    return promedio / cantidad

lista = [13, 24, 31, 46, 1, 2, 9 ]

print("El promedio de los numeros menores a 10 es:", promedio(lista))
