# Escribir una función que calcule el total de una 
# factura tras aplicarle el IVA. La función debe 
# recibir la cantidad sin IVA y el porcentaje de 
# IVA a aplicar, y devolver el total de la factura. 


def calcular_iva(cantidad, porcentaje):
    iva = cantidad * porcentaje / 100
    return cantidad + iva

importe_neto = float(input("Ingrese el importe neto: "))
iva = float(input("Ingrese el porcentaje de IVA: "))
importe_total = calcular_iva(importe_neto, iva)

print("El importe total es: ", importe_total)