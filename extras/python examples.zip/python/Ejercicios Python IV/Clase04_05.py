# Escribir una función que reciba una lista de números
# y devuelva su promedio.

def promedio(lista):
    suma = 0
    for i in lista:
        suma += i
    return suma / len(lista)


numeros = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

print("El promedio es:", promedio(numeros))