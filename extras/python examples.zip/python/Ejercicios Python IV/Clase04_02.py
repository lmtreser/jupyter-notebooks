# Escribir una función a la que se le pase una cadena
# <nombre> y muestre por pantalla el saludo 
# ¡hola <nombre>!.

def saludo(nombre):
    print("¡Hola " + nombre + "!")

saludo("Juan")
saludo("Pedro")
saludo("Maria")



