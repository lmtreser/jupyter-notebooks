# Escribir una función que calcule el área de un 
# círculo y otra que calcule el volumen de un
# cilindro usando la primera función.

def area_circulo(radio):
    return 3.1416 * radio ** 2

def vol_cilindro(radio, altura):
    return area_circulo(radio) * altura

radio  = float(input(" Ingrese el radio: "))
altura = float(input("Ingrese la altura: "))
print("El area del circulo es: ", area_circulo(radio))

