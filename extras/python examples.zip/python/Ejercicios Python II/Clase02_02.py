# Escribir un programa que almacene la cadena
# de caracteres contraseña en una variable, 
# pregunte al usuario por la contraseña e imprima
# por pantalla si la contraseña introducida por
# el usuario coincide con la guardada en la
# variable.

clave_ok = "micontraseña"
clave = input("Introduce la contraseña: ")

if clave == clave_ok:
    print("Contraseña correcta")
else:
    print("Contraseña incorrecta")


