# Escribir un programa que pida al usuario una 
# palabra y luego muestre por pantalla una a una 
# las letras de la palabra introducida empezando 
# por la última.

palabra = input("Ingrese una palabra: ")

longitud = len(palabra)
indice = longitud - 1

while indice >= 0:
    print(palabra[indice], end="")
    indice -= 1


# for letra in palabra[::-1]:
#     print(letra, end=" ")

