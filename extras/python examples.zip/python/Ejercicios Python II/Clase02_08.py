# Escribir un programa que pida al usuario un número
# entero y muestre por pantalla un triángulo rectángulo
# como el de más abajo.
#
# 1
# 3 1
# 5 3 1
# 7 5 3 1
# 9 7 5 3 1


fila = 1

while fila <= 5:
    valor   = fila * 2 - 1

    while valor > 0:    
        print(valor, end=" ")
        valor -= 2

    print()    
    fila += 1