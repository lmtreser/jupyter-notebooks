# Escribir un programa que pregunte al usuario su
# edad y muestre por pantalla si es mayor de edad 
# o no.

edad = int(input("Ingrese su edad: "))
if edad >= 18:
    print("Usted es mayor de edad")
else:
    print("Usted es menor de edad")

