# Escribir un programa que pida al usuario dos
# números y muestre por pantalla su división. 
# Si el divisor es cero el programa debe mostrar
# un error.

num1 = int(input("Ingrese un numero: "))
num2 = int(input("Ingrese otro numero: "))

if num2 == 0:
    print("Error")
else:
    print(num1 / num2)
