# Para tributar un determinado impuesto se debe ser mayor
# de 18 años y tener unos ingresos mensuales iguales o 
# superiores a $ 30000. 
# Escribir un programa que pregunte al usuario su edad y 
# sus ingresos mensuales y muestre por pantalla si el usuario
# tiene que tributar o no.

edad = int(input("Introduce tu edad: "))
ingresos = int(input("Introduce tus ingresos: "))

if edad > 18 and ingresos > 30000:
    print("Tienes que tributar")    
else:
    print("No tienes que tributar")

