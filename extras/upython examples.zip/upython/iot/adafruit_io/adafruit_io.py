 
import network, urandom
from umqtt.robust import MQTTClient
from machine import Timer, Pin
from time import sleep_ms

#--- Credenciales ------------------------------------#
wifi_ssid = "ssid"
wifi_password = "password"

mqtt_server = "io.adafruit.com"
mqtt_user = "user"
mqtt_password = "aio_key"
mqtt_topic_1 = "{user}/feeds/{feedname}"
mqtt_topic_2 = "{user}/feeds/{feedname}"

#--- Setup ------------------------------------------#
pin_2 = Pin(2, Pin.OUT, value=0)

#--- Conexión a WiFi --------------------------------#
wlan = network.WLAN(network.STA_IF)
if not wlan.active():
    wlan.active(True)

if not wlan.isconnected():
    wlan.connect(wifi_ssid, wifi_password)

    print("Conectando...")
    while not wlan.isconnected():
        sleep_ms(1000)

config = wlan.ifconfig()
print(f"Conectado con ip {config[0]}")

#--- Conexión a MQTT --------------------------------#
def callback(topic, msg):
    topic = topic.decode()
    msg = msg.decode()
    print(f"Llegó {msg} de {topic}")

    # De acuerdo al mensaje recibido, encender o apagar el pin 2
    if topic == mqtt_topic_1 and msg == "ON":
        pin_2.on()
    elif topic == mqtt_topic_1 and msg == "OFF":
        pin_2.off()

# Obtener la dirección MAC para el ID del cliente
mac = wlan.config('mac')
mac_address = ':'.join('{:02x}'.format(b) for b in mac)
print("Dirección MAC:", mac_address)

cliente = MQTTClient(mac_address, mqtt_server, user=mqtt_user, 
                        password=mqtt_password, keepalive=30)
print("Conectando a Adafruit IO...")
cliente.set_callback(callback)
cliente.connect(clean_session=False)
print("Conectado")
cliente.subscribe(mqtt_topic_1)

# Publicar en el servidor un valor aleatorio
def publisher(timer):
    temperature = urandom.randint(0, 50)
    print("Publicando", temperature, "°C")
    cliente.publish(mqtt_topic_2, str(temperature))

tim = Timer(0)
tim.init(period=10000, mode=Timer.PERIODIC, callback=publisher)

#--- Bucle infinito ----------------------------------#
while True:
    cliente.check_msg()
    sleep_ms(500)