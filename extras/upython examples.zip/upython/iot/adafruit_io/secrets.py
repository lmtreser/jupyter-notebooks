#--- Credenciales -----------------------------------#
WIFI_SSID = "ssid"
WIFI_PASSWORD = "password"

MQTT_BROKER = "host"
MQTT_USER = "username"
MQTT_PASSWORD = "aio_"
MQTT_PORT = 1883
MQTT_CLIENT_ID = "id"
MQTT_WELCOME_MSG = "System INIT!"

MQTT_TOPIC_0 = "{username}/feeds/{feedname}"
MQTT_TOPIC_1 = "{username}/feeds/{feedname}"
MQTT_TOPIC_2 = "{username}/feeds/{feedname}"
MQTT_TOPIC_3 = "{username}/feeds/{feedname}"