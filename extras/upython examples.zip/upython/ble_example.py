# This example demonstrates a UART periperhal.

import bluetooth
import random
import struct
import time

from ble_simple_peripheral import BLESimplePeripheral
from ble_advertising import advertising_payload
from micropython import const

ble = bluetooth.BLE()
p = BLESimplePeripheral(ble)

# Recepción de datos
def on_rx(v):
    print("RX", v)

p.on_write(on_rx)

# Envio de datos
i = 0
while True:
    if p.is_connected():
        # Short burst of queued notifications.
        for _ in range(3):
            data = str(i) + "_"
            print("TX", data)
            p.send(data)
            i += 1
    time.sleep_ms(1000)