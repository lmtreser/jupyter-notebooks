import streamlit as st
#from paho.mqtt import client as mqtt_client
import paho.mqtt.client as mqtt

# Configuración MQTT
BROKER = "test.mosquitto.org"  # Cambia por tu broker
PORT = 1883
TOPIC_SUBSCRIBE = "test/streamlit/receive"  # Cambia según tu tópico
TOPIC_PUBLISH = "test/streamlit/send"       # Cambia según tu tópico

# Variables de estado en Streamlit
if "mqtt_client" not in st.session_state:
    st.session_state.mqtt_client = None
if "messages" not in st.session_state:
    st.session_state.messages = []

# Callback para recibir mensajes
def on_message(client, userdata, msg):
    message = msg.payload.decode()
    st.session_state.messages.append(f"{msg.topic}: {message}")

# Conectar al broker
def connect_mqtt():
    client = mqtt.Client(client_id="client_id", callback_api_version=mqtt.CallbackAPIVersion.VERSION2)
    client.on_message = on_message
    client.connect(BROKER, PORT, 60)
    client.subscribe(TOPIC_SUBSCRIBE)
    client.loop_start()  # Iniciar bucle en segundo plano
    st.session_state.mqtt_client = client

# Publicar mensaje
def publish_message(message):
    if st.session_state.mqtt_client:
        st.session_state.mqtt_client.publish(TOPIC_PUBLISH, message)
    else:
        st.error("Conexión MQTT no establecida.")

# Desconectar del broker
def disconnect_mqtt():
    if st.session_state.mqtt_client:
        st.session_state.mqtt_client.loop_stop()
        st.session_state.mqtt_client.disconnect()
        st.session_state.mqtt_client = None

# Interfaz Streamlit
st.title("Streamlit con MQTT")

# Botones para conectar/desconectar
if st.button("Conectar MQTT"):
    connect_mqtt()

if st.button("Desconectar MQTT"):
    disconnect_mqtt()

# Enviar mensaje
message = st.text_input("Escribe un mensaje para enviar")
if st.button("Enviar mensaje"):
    publish_message(message)

# Mostrar mensajes recibidos
st.subheader("Mensajes recibidos:")
st.write("\n".join(st.session_state.messages))