import streamlit as st

st.title("Organización de elementos en Streamlit")

# Usar columnas
col1, col2 = st.columns([1, 2])
col1.write("Columna más pequeña")
col2.write("Columna más grande")

# Usar un contenedor
with st.container():
    st.write("Esto está dentro de un contenedor")
    col1, col2 = st.columns(2)
    col1.write("Columna 1")
    col2.write("Columna 2")

# Usar un expansor
with st.expander("Más detalles"):
    st.write("Información adicional dentro de un expansor.")

# Pestañas
tab1, tab2 = st.tabs(["Primera pestaña", "Segunda pestaña"])
with tab1:
    st.write("Contenido de la primera pestaña")
with tab2:
    st.write("Contenido de la segunda pestaña")